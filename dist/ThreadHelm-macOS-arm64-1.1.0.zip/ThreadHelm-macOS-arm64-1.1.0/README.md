# ThreadHelm macOS 版

## 安装

1. 完整解压 `ThreadHelm-macOS-arm64-1.1.0.zip`。
2. 双击 `安装ThreadHelm.command`。
3. 如果出现“Apple 无法验证”提示，点“完成”，不要点“移到废纸篓”。
4. 打开“系统设置”中的“隐私与安全”。
5. 点击“仍要打开”或 “Open Anyway”，输入 Mac 登录密码确认。
6. 重新双击 `安装ThreadHelm.command`。
7. 安装器会复制并启动 `~/Applications/ThreadHelm.app`，LaunchAgent label 为 `dev.threadhelm.app`。
8. 若希望当前 Codex 运行中新建任务的原生气泡也自动静音，可在“系统设置 → 隐私与安全 → 辅助功能”中为“ThreadHelm”开启权限。

“仍要打开”按钮只会在尝试启动安装文件后出现，并会保留约一小时。
[查看 Apple 官方的允许步骤](https://support.apple.com/guide/mac-help/mh40616/mac)。

## 要求

- macOS 12.3+
- Apple 芯片（arm64）；暂不支持 Intel Mac
- 已安装并登录 Codex，用于读取本机额度与任务状态
- Claude Code 额度与任务兼容为可选功能；可使用独立 Claude Code CLI 或 Claude Desktop 内置 CLI，二者均未安装时 ThreadHelm 自动隐藏额度入口
- Cursor、ZCode 和 OMP 都是可选本机任务来源；未安装或版本未验证的 Agent 不会被安装器创建或改写配置，卸载器仍可只移除 ThreadHelm 自己的条目

## 包内容

- `ThreadHelm.app`：独立 macOS App，包含灵动岛、额度和任务状态功能。
- `dev.threadhelm.app.plist.in`：当前用户 LaunchAgent 模板。
- `安装ThreadHelm.command`：安装 App 和 LaunchAgent。
- `检查ThreadHelm.command`：检查 App、arm64 架构、签名、LaunchAgent、运行状态、Codex 周额度、可选 Claude 三项额度和任务状态。
- `卸载ThreadHelm.command`：卸载 App 和 LaunchAgent，并恢复本项目记录过的 Codex 原生气泡静音值。
- `local-install-transaction.zsh`：安装失败时恢复旧 App、LaunchAgent 和四个受管 Agent 集成。
- `LICENSE`、`PRIVACY.md`、`ASSET-NOTICE.md`、`CHECKSUMS-SHA256.txt`。

## 功能

- ThreadHelm 是独立 App，不包含桌面宠物，也不再向 `$CODEX_HOME/pets` 安装宠物或写入 Codex `selected-avatar-id`。
- 灵动岛默认是胶囊，点击后展开为功能面板；胶囊可拖到其他屏幕并吸附到该屏幕顶部中央。
- 检测到独立 Claude Code CLI 或 Claude Desktop 内置 CLI 时可切换额度来源：Codex 显示周额度，Claude Code 同时显示 5h、周额度与 Fable 周额度；不显示 Token、Credits 或任何行情模块。
- 任务状态统一呈现 Codex、Claude Code（包括 Claude Desktop 本地 Agent 会话）、Cursor、ZCode 和 OMP，并区分需要你、执行中与最近完成；Desktop 会话保持只读，不会被当成可通过终端精确返回的 CLI 会话。
- 运行中任务显示开始时间与持续时间；运行中最新一条会交替替换展示，详情区可滚动查看完整公开输出。
- 点击 Codex 任务会通过官方深链打开，点击 Claude 任务会在原工作目录通过 Terminal 恢复会话。
- 本机读取 Codex app-server，以及已安装 Claude CLI 的 `/usage`、`agents --json`、CLI 会话公开输出和 Claude Desktop 本地 Agent transcript；不会发起远程第三方行情请求。
- 任务名称、已读状态、额度百分比和重置时间只在本机读取和显示，不写入发布包，也不上传。
- 不需要管理员权限或另行填写 API Key；辅助功能权限仅是当前运行中新任务气泡自动静音的可选增强。

## 检查与卸载

- `检查ThreadHelm.command`：检查 `~/Applications/ThreadHelm.app`、`dev.threadhelm.app`、签名、进程、运行状态、五 Agent 集成状态、Codex 周额度、可选 Claude 三项额度和任务状态。
- `卸载ThreadHelm.command`：完全退出 Codex 后，先移除四个 ThreadHelm 受管 Agent 集成，再移除 App 与 LaunchAgent，并只恢复本项目添加的 Codex 原生气泡设置；Codex 仍运行时会停止卸载并保留恢复文件。
